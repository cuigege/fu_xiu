create trigger TRI_T_ZSCX_SFFS
    before insert
    on T_ZSCX_SFFS
    for each row
    when (new.id is null)
begin
  select s_T_ZSCX_SFFS.nextval into :new.id from dual ; /*从虚拟表中查到下一个未被使用的新的id,使用过弃用，接着往下*/
end;

/

