create trigger TRI_T_FXGL_FXCJ
    before insert
    on T_FXGL_FXCJ
    for each row
    when (new.id is null)
begin
  select s_T_FXGL_FXCJ.nextval into :new.id from dual ; /*从虚拟表中查到下一个未被使用的新的id,使用过弃用，接着往下*/
end;
/

